import pickle
from collections import defaultdict

class TextIndex:
    def __init__(self, index_file='data/text_index.pickle'):
        self.__dict__.update(pickle.load(open(index_file, 'rb')))

    def show_symbols(self, symbols):
        from IPython.core.display import display, HTML
        if type(symbols) is str:
            symbols = set((symbol,))
        else:
            symbols = set(symbols)

        # Sélections des § et indique où mettre du gras et en quelle couleur
        selections = defaultdict(set)
        # Famille et l'ensemble de gènes query associés
        fam2sym = defaultdict(set)

        # Cherche les symbols de genes dans le text
        for symbol in symbols:
            family = self.gene_families.get(symbol)
            if family:
                fam2sym[family].add(symbol)
                color = self.families_color[family]
            else:
                color = 'black'
            for parid, poss in self.symbol_matchs.get(symbol, []):
                selections[parid].update((start, stop, color) for start, stop in poss)

        # Cherche les familles dans le texte
        families_found = fam2sym.keys() & self.family_matchs.keys()
        for family in families_found:
            for parid, poss in self.family_matchs[family]:
                selections[parid].update((start, stop, self.families_color[family]) for start, stop in poss)

        output = [] # Sortie html
        if not selections:
            output = 'Pas de résultats trouvé pour %s' % ', '.join(symbols)
        else:
            if fam2sym:
                output.append('<p>Les symbols trouvés sont en <b>gras</b>. La couleur indique la famille :</p><ul>')
                for family, symbols in fam2sym.items():
                    color = self.families_color[family]

                    if family in families_found:
                        family = '<b style="color: {color};">{family}</b>'.format_map(locals())

                    genes_found =    ' '.join(symbols & self.symbol_matchs.keys())
                    genes_notfound = ' '.join(symbols - self.symbol_matchs.keys())
                    output.append('<li>Famille {family} : Gènes <b style="color: {color};">{genes_found}</b> {genes_notfound}</li>'.format_map(locals()))
                output.append('</ul>')

            old_titles_stack = []
            for parid, parsels in sorted(selections.items()):
                titles, parnumber, text = self.paragraphs[parid]

                # Cherche les titre différents du paragraphe précédent pour les rajouter dans la sortie
                for level, title in enumerate(titles):
                    if level >= len(old_titles_stack) or title != old_titles_stack[level]:
                        output.append('<h{0}>{1}</h{0}>'.format(level+1, title))

                # Rajoute le paragraphe dans la sortie
                output.append('<p><b><i>§%d </i></b>' % parnumber)
                prev_stop = 0
                for start, stop, color in sorted(parsels):
                    output.append(text[prev_stop:start])
                    output.append('<b style="color: %s;">%s</b>' % (color, text[start:stop]))
                    prev_stop = stop
                output.append(text[prev_stop:] + '</p>')

                old_titles_stack = titles

        return display(HTML(''.join(output)))
